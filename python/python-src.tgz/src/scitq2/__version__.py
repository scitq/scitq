# generated at build time
__version__ = '0.8.2.dev37+gce96294.dev0.b20260528121310'
__commit__ = 'ce96294'
__build_time__ = '2026-05-28T12:13:10Z'
