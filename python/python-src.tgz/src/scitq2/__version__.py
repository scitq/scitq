# generated at build time
__version__ = '0.7.1.dev26+gc5fd8ed.dev0'
__commit__ = 'c5fd8ed'
__build_time__ = '2026-04-11T06:13:53Z'
