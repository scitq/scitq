# generated at build time
__version__ = '0.7.5.dev1+gb7c4d1b.dev0'
__commit__ = 'b7c4d1b'
__build_time__ = '2026-04-23T12:58:32Z'
