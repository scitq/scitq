# generated at build time
__version__ = '0.8.8.dev17+g342f621.dev0.b20260629204140'
__commit__ = '342f621'
__build_time__ = '2026-06-29T20:41:40Z'
