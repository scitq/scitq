# generated at build time
__version__ = '0.8.8.dev20+g0d044b3.dev0.b20260701115553'
__commit__ = '0d044b3'
__build_time__ = '2026-07-01T11:55:53Z'
