# generated at build time
__version__ = '0.9.2.dev7+g3bbb9fc.dev0.b20260921135450'
__commit__ = '3bbb9fc'
__build_time__ = '2026-09-21T13:54:50Z'
