# generated at build time
__version__ = '0.8.2.dev36+g657b0f5.dev0.b20260526070846'
__commit__ = '657b0f5'
__build_time__ = '2026-05-26T07:08:46Z'
