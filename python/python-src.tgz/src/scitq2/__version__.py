# generated at build time
__version__ = '0.7.1.dev15+g9649ca3.dev0'
__commit__ = '9649ca3'
__build_time__ = '2026-04-08T12:13:44Z'
