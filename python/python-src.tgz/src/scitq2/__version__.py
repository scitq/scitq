# generated at build time
__version__ = '0.8.8.dev22+ga7362da.dev0.b20260701134632'
__commit__ = 'a7362da'
__build_time__ = '2026-07-01T13:46:32Z'
