# generated at build time
__version__ = '0.7.7.dev4+g36cd11d.dev0'
__commit__ = '36cd11d'
__build_time__ = '2026-05-01T11:31:03Z'
