# generated at build time
__version__ = '0.8.8.dev1+gdec5da8.dev0.b20260619082115'
__commit__ = 'dec5da8'
__build_time__ = '2026-06-19T08:21:15Z'
