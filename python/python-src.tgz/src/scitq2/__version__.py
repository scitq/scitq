# generated at build time
__version__ = '0.8.8.dev14+g82acd9a.dev0.b20260628080729'
__commit__ = '82acd9a'
__build_time__ = '2026-06-28T08:07:29Z'
