# generated at build time
__version__ = '0.7.8.dev4+g89a2f0a.dev0'
__commit__ = '89a2f0a'
__build_time__ = '2026-05-03T19:34:13Z'
