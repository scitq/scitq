# generated at build time
__version__ = '0.8.2.dev27+gac5dcfb.dev0.b20260520173403'
__commit__ = 'ac5dcfb'
__build_time__ = '2026-05-20T17:34:03Z'
