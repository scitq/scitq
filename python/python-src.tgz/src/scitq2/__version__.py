# generated at build time
__version__ = '0.8.2.dev35+g84ceebc.dev0.b20260525135510'
__commit__ = '84ceebc'
__build_time__ = '2026-05-25T13:55:10Z'
