# generated at build time
__version__ = '0.8.dev1+gc9e33b4.dev0'
__commit__ = 'c9e33b4'
__build_time__ = '2026-05-05T10:19:25Z'
