# generated at build time
__version__ = '0.8.2.dev17+g97c7eb5.dev0.b20260518165726'
__commit__ = '97c7eb5'
__build_time__ = '2026-05-18T16:57:26Z'
