# generated at build time
__version__ = '0.8.8.dev25+g6da4527.dev0.b20260703081951'
__commit__ = '6da4527'
__build_time__ = '2026-07-03T08:19:51Z'
