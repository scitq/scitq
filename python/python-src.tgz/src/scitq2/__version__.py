# generated at build time
__version__ = '0.8.7.dev1+ga11a3bb.dev0.b20260617081652'
__commit__ = 'a11a3bb'
__build_time__ = '2026-06-17T08:16:52Z'
