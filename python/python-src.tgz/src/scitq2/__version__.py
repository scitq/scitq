# generated at build time
__version__ = '0.8.8.dev0+b20260619073742'
__commit__ = 'a2a60da'
__build_time__ = '2026-06-19T07:37:42Z'
