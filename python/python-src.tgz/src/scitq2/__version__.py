# generated at build time
__version__ = '0.7.7.dev3+g911641c.dev0'
__commit__ = '911641c'
__build_time__ = '2026-04-30T16:08:55Z'
