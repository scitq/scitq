# generated at build time
__version__ = '0.8.2.dev38+g8ad75b1.dev0.b20260529085800'
__commit__ = '8ad75b1'
__build_time__ = '2026-05-29T08:58:00Z'
