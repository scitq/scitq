# generated at build time
__version__ = '0.8.2.dev25+g8234cd9.dev0.b20260519200430'
__commit__ = '8234cd9'
__build_time__ = '2026-05-19T20:04:30Z'
