# generated at build time
__version__ = '0.8.1.dev6+g22219dd.dev0.b20260510153619'
__commit__ = '22219dd'
__build_time__ = '2026-05-10T15:36:19Z'
