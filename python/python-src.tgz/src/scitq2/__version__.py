# generated at build time
__version__ = '0.8.2.dev6+gefbfb7f.dev0.b20260514145407'
__commit__ = 'efbfb7f'
__build_time__ = '2026-05-14T14:54:07Z'
