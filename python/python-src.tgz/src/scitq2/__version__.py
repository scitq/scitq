# generated at build time
__version__ = '0.8.2.dev42+g49d6a19.dev0.b20260531124139'
__commit__ = '49d6a19'
__build_time__ = '2026-05-31T12:41:39Z'
