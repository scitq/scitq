# generated at build time
__version__ = '0.8.8.dev11+gf2e863c.dev0.b20260625155236'
__commit__ = 'f2e863c'
__build_time__ = '2026-06-25T15:52:36Z'
