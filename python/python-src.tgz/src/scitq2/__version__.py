# generated at build time
__version__ = '0.8.2.dev59+g1e843a5.dev0.b20260613071740'
__commit__ = '1e843a5'
__build_time__ = '2026-06-13T07:17:40Z'
