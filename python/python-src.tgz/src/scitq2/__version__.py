# generated at build time
__version__ = '0.8.2.dev43+g12e427b.dev0.b20260531135420'
__commit__ = '12e427b'
__build_time__ = '2026-05-31T13:54:20Z'
