# generated at build time
__version__ = '0.7.1.dev20+g5b3af82.dev0'
__commit__ = '5b3af82'
__build_time__ = '2026-04-08T16:17:14Z'
