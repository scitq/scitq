# generated at build time
__version__ = '0.7.1.dev21+gee22ff3.dev0'
__commit__ = 'ee22ff3'
__build_time__ = '2026-04-09T06:09:44Z'
