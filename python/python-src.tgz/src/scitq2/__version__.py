# generated at build time
__version__ = '0.7.1.dev28+g5237e20.dev0'
__commit__ = '5237e20'
__build_time__ = '2026-04-11T09:47:14Z'
