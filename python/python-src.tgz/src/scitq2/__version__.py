# generated at build time
__version__ = '0.8.2.dev10+g4f04e30.dev0.b20260515195035'
__commit__ = '4f04e30'
__build_time__ = '2026-05-15T19:50:35Z'
