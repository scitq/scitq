# generated at build time
__version__ = '0.8.7.dev7+g775abca.dev0.b20260618124423'
__commit__ = '775abca'
__build_time__ = '2026-06-18T12:44:23Z'
