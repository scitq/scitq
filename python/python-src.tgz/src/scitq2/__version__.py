# generated at build time
__version__ = '0.7.1.dev7+g1234056.dev0'
__commit__ = '1234056'
__build_time__ = '2026-04-05T11:16:32Z'
