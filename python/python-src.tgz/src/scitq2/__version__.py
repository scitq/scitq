# generated at build time
__version__ = '0.7.1.dev14+g6a2428a.dev0'
__commit__ = '6a2428a'
__build_time__ = '2026-04-08T11:31:44Z'
