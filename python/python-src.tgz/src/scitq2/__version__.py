# generated at build time
__version__ = '0.8.2.dev4+g2266c70.dev0.b20260513154049'
__commit__ = '2266c70'
__build_time__ = '2026-05-13T15:40:49Z'
