# generated at build time
__version__ = '0.7.1.dev6+g9b74ae2.dev0'
__commit__ = '9b74ae2'
__build_time__ = '2026-04-05T11:01:36Z'
