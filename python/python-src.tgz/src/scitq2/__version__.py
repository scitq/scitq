# generated at build time
__version__ = '0.8.9.dev0+b20260703214551'
__commit__ = '4b28d27'
__build_time__ = '2026-07-03T21:45:51Z'
