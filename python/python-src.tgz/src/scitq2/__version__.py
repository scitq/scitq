# generated at build time
__version__ = '0.8.2.dev50+g79c0fba.dev0.b20260604081334'
__commit__ = '79c0fba'
__build_time__ = '2026-06-04T08:13:34Z'
