# generated at build time
__version__ = '0.8.7.dev0+b20260617070433'
__commit__ = '7d08562'
__build_time__ = '2026-06-17T07:04:33Z'
