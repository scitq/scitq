# generated at build time
__version__ = '0.8.8.dev5+g67b761e.dev0.b20260624082157'
__commit__ = '67b761e'
__build_time__ = '2026-06-24T08:21:57Z'
