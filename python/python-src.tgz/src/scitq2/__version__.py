# generated at build time
__version__ = '0.8.8.dev16+g0ac6a11.dev0.b20260629124841'
__commit__ = '0ac6a11'
__build_time__ = '2026-06-29T12:48:41Z'
