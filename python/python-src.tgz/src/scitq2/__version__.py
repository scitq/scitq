# generated at build time
__version__ = '0.7.1.dev27+g143a878.dev0'
__commit__ = '143a878'
__build_time__ = '2026-04-11T07:46:58Z'
