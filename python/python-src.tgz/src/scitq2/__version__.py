# generated at build time
__version__ = '0.7.2.dev4+g88bcc12.dev0'
__commit__ = '88bcc12'
__build_time__ = '2026-04-12T09:03:15Z'
