# generated at build time
__version__ = '0.8.2.dev33+g1274212.dev0.b20260524095952'
__commit__ = '1274212'
__build_time__ = '2026-05-24T09:59:52Z'
