# generated at build time
__version__ = '0.8.2.dev49+g950a58d.dev0.b20260604074634'
__commit__ = '950a58d'
__build_time__ = '2026-06-04T07:46:34Z'
