# generated at build time
__version__ = '0.7.1.dev29+g6ae058b.dev0'
__commit__ = '6ae058b'
__build_time__ = '2026-04-11T10:09:30Z'
