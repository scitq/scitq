# generated at build time
__version__ = '0.8.8.dev23+g7c04236.dev0.b20260701161155'
__commit__ = '7c04236'
__build_time__ = '2026-07-01T16:11:55Z'
