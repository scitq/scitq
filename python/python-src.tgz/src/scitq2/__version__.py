# generated at build time
__version__ = '0.7.1.dev22+gb7a1dfd.dev0'
__commit__ = 'b7a1dfd'
__build_time__ = '2026-04-09T12:01:10Z'
