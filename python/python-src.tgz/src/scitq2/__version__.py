# generated at build time
__version__ = '0.7.1.dev11+gf6c8670.dev0'
__commit__ = 'f6c8670'
__build_time__ = '2026-04-08T07:47:56Z'
