# generated at build time
__version__ = '0.8.8.dev15+gb7acc42.dev0.b20260628211500'
__commit__ = 'b7acc42'
__build_time__ = '2026-06-28T21:15:00Z'
