# generated at build time
__version__ = '0.8.8.dev18+gf51a197.dev0.b20260630113409'
__commit__ = 'f51a197'
__build_time__ = '2026-06-30T11:34:09Z'
