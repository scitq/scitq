# generated at build time
__version__ = '0.8.2.dev2+gbb65cb8.dev0.b20260512200523'
__commit__ = 'bb65cb8'
__build_time__ = '2026-05-12T20:05:23Z'
