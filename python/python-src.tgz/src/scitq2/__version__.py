# generated at build time
__version__ = '0.9.2.dev2+g44a9fac.dev0.b20260919172102'
__commit__ = '44a9fac'
__build_time__ = '2026-09-19T17:21:02Z'
