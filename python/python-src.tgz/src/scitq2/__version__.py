# generated at build time
__version__ = '0.8.2.dev47+g63f7c83.dev0.b20260603115236'
__commit__ = '63f7c83'
__build_time__ = '2026-06-03T11:52:36Z'
