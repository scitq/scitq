# generated at build time
__version__ = '0.7.5.dev3+ga83dd52.dev0'
__commit__ = 'a83dd52'
__build_time__ = '2026-04-25T10:23:14Z'
