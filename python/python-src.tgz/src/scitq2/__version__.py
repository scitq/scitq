# generated at build time
__version__ = '0.8.2.dev14+gf2abde5.dev0.b20260516080120'
__commit__ = 'f2abde5'
__build_time__ = '2026-05-16T08:01:20Z'
