# generated at build time
__version__ = '0.8.2.dev48+gf44109a.dev0.b20260603144000'
__commit__ = 'f44109a'
__build_time__ = '2026-06-03T14:40:00Z'
