# generated at build time
__version__ = '0.9.2.dev3+g93cc3c1.dev0.b20260920084203'
__commit__ = '93cc3c1'
__build_time__ = '2026-09-20T08:42:03Z'
