# generated at build time
__version__ = '0.7.6.dev1+gd922560.dev0'
__commit__ = 'd922560'
__build_time__ = '2026-04-26T20:21:47Z'
