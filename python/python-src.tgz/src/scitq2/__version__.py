# generated at build time
__version__ = '0.7.1.dev19+g8e4670f.dev0'
__commit__ = '8e4670f'
__build_time__ = '2026-04-08T14:15:11Z'
