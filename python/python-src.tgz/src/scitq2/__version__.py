# generated at build time
__version__ = '0.7.1.dev23+g1f35c68.dev0'
__commit__ = '1f35c68'
__build_time__ = '2026-04-10T21:34:41Z'
