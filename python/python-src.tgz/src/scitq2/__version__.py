# generated at build time
__version__ = '0.9.2.dev5+g5c7b471.dev0.b20260921064529'
__commit__ = '5c7b471'
__build_time__ = '2026-09-21T06:45:29Z'
