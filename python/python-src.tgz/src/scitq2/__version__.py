# generated at build time
__version__ = '0.7.7.dev5+g2a7b9c2.dev0'
__commit__ = '2a7b9c2'
__build_time__ = '2026-05-01T20:09:11Z'
