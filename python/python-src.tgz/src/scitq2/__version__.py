# generated at build time
__version__ = '0.7.1.dev18+gb10ab53.dev0'
__commit__ = 'b10ab53'
__build_time__ = '2026-04-08T13:43:39Z'
