# generated at build time
__version__ = '0.8.8.dev19+g8fa355f.dev0.b20260701084134'
__commit__ = '8fa355f'
__build_time__ = '2026-07-01T08:41:34Z'
