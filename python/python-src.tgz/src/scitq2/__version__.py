# generated at build time
__version__ = '0.8.2.dev63+g1e9141a.dev0.b20260613122005'
__commit__ = '1e9141a'
__build_time__ = '2026-06-13T12:20:05Z'
