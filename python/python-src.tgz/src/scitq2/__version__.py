# generated at build time
__version__ = '0.8.8.dev4+g151020d.dev0.b20260622085832'
__commit__ = '151020d'
__build_time__ = '2026-06-22T08:58:32Z'
