# generated at build time
__version__ = '0.8.2.dev41+gb5cc368.dev0.b20260531092221'
__commit__ = 'b5cc368'
__build_time__ = '2026-05-31T09:22:21Z'
