# generated at build time
__version__ = '0.8.2.dev46+gc063c55.dev0.b20260603105255'
__commit__ = 'c063c55'
__build_time__ = '2026-06-03T10:52:55Z'
