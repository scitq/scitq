# generated at build time
__version__ = '0.7.4.dev18+g0d9ce4f.dev0'
__commit__ = '0d9ce4f'
__build_time__ = '2026-04-22T14:03:59Z'
