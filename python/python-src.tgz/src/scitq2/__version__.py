# generated at build time
__version__ = '0.8.2.dev11+g2daf569.dev0.b20260515202405'
__commit__ = '2daf569'
__build_time__ = '2026-05-15T20:24:05Z'
