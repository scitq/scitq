# generated at build time
__version__ = '0.8.8.dev7+g7b8f791.dev0.b20260624110913'
__commit__ = '7b8f791'
__build_time__ = '2026-06-24T11:09:13Z'
