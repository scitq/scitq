# generated at build time
__version__ = '0.8.2.dev8+g8af1f96.dev0.b20260515070116'
__commit__ = '8af1f96'
__build_time__ = '2026-05-15T07:01:16Z'
