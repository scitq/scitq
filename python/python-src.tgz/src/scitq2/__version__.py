# generated at build time
__version__ = '0.7.4.dev17+gdeeed94.dev0'
__commit__ = 'deeed94'
__build_time__ = '2026-04-22T12:40:17Z'
