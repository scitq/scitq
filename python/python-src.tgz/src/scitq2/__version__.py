# generated at build time
__version__ = '0.8.8.dev13+g2bc545d.dev0.b20260627130427'
__commit__ = '2bc545d'
__build_time__ = '2026-06-27T13:04:27Z'
