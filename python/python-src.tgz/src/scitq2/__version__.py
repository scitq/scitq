# generated at build time
__version__ = '0.8.2.dev61+g5fdb56e.dev0.b20260613093317'
__commit__ = '5fdb56e'
__build_time__ = '2026-06-13T09:33:17Z'
