# generated at build time
__version__ = '0.9.2.dev8+g44ad71f.dev0.b20260922054609'
__commit__ = '44ad71f'
__build_time__ = '2026-09-22T05:46:09Z'
