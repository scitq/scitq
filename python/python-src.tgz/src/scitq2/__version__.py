# generated at build time
__version__ = '0.8.9.dev1+gbbfa11d.dev0.b20260705083429'
__commit__ = 'bbfa11d'
__build_time__ = '2026-07-05T08:34:29Z'
