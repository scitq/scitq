# generated at build time
__version__ = '0.8.7.dev2+g3a35e8c.dev0.b20260617093740'
__commit__ = '3a35e8c'
__build_time__ = '2026-06-17T09:37:40Z'
