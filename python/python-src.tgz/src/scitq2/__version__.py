# generated at build time
__version__ = '0.7.8.dev2+g3ffe81c.dev0'
__commit__ = '3ffe81c'
__build_time__ = '2026-05-03T11:35:06Z'
