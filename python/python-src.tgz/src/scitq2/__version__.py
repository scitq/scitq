# generated at build time
__version__ = '0.8.8.dev12+g3103ec9.dev0.b20260627095750'
__commit__ = '3103ec9'
__build_time__ = '2026-06-27T09:57:50Z'
