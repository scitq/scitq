# generated at build time
__version__ = '0.8.6.dev1+g9185a3a.dev0.b20260616153417'
__commit__ = '9185a3a'
__build_time__ = '2026-06-16T15:34:17Z'
