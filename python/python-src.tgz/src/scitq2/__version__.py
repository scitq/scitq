# generated at build time
__version__ = '0.8.2.dev18+g964741e.dev0.b20260518172300'
__commit__ = '964741e'
__build_time__ = '2026-05-18T17:23:00Z'
