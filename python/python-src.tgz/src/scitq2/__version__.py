# generated at build time
__version__ = '0.9.1.dev7+gc1a7a91.dev0.b20260910213156'
__commit__ = 'c1a7a91'
__build_time__ = '2026-09-10T21:31:56Z'
