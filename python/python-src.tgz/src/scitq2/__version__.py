# generated at build time
__version__ = '0.7.8.dev5+g2071b10.dev0'
__commit__ = '2071b10'
__build_time__ = '2026-05-04T05:52:33Z'
