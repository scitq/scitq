# generated at build time
__version__ = '0.8.2.dev64+gbfcb286.dev0.b20260613143707'
__commit__ = 'bfcb286'
__build_time__ = '2026-06-13T14:37:07Z'
