# generated at build time
__version__ = '0.7.1.dev10+g0b291fa.dev0'
__commit__ = '0b291fa'
__build_time__ = '2026-04-08T07:08:09Z'
