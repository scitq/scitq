# generated at build time
__version__ = '0.8.2.dev52+g2ecd1f6.dev0.b20260606093745'
__commit__ = '2ecd1f6'
__build_time__ = '2026-06-06T09:37:45Z'
