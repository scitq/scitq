# generated at build time
__version__ = '0.8.2.dev12+g549bd60.dev0.b20260515203510'
__commit__ = '549bd60'
__build_time__ = '2026-05-15T20:35:10Z'
