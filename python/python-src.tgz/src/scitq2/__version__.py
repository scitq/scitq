# generated at build time
__version__ = '0.7.dev14+g0cbd24f'
__commit__ = '0cbd24f'
__build_time__ = '2026-04-01T11:04:42Z'
