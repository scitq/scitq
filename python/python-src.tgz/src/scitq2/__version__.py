# generated at build time
__version__ = '0.7.6.dev0'
__commit__ = 'a307f35'
__build_time__ = '2026-04-26T19:31:31Z'
