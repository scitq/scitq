# generated at build time
__version__ = '0.7.1.dev5+gdc77753.dev0'
__commit__ = 'dc77753'
__build_time__ = '2026-04-04T21:01:28Z'
