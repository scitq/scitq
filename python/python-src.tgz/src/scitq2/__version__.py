# generated at build time
__version__ = '0.8.8.dev21+g81b6bd4.dev0.b20260701123234'
__commit__ = '81b6bd4'
__build_time__ = '2026-07-01T12:32:34Z'
