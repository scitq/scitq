# generated at build time
__version__ = '0.8.6.dev0+b20260616100447'
__commit__ = '73d6d9a'
__build_time__ = '2026-06-16T10:04:47Z'
