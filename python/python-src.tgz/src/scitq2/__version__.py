# generated at build time
__version__ = '0.7.3.dev6+g3fabb82.dev0'
__commit__ = '3fabb82'
__build_time__ = '2026-04-15T16:18:49Z'
