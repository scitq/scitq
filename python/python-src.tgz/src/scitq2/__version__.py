# generated at build time
__version__ = '0.8.dev0'
__commit__ = '596c25e'
__build_time__ = '2026-05-05T08:26:20Z'
