# generated at build time
__version__ = '0.7.4.dev4+g7673d19.dev0'
__commit__ = '7673d19'
__build_time__ = '2026-04-17T09:19:37Z'
