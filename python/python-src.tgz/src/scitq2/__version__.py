# generated at build time
__version__ = '0.8.8.dev24+g2e3ffa3.dev0.b20260702084705'
__commit__ = '2e3ffa3'
__build_time__ = '2026-07-02T08:47:05Z'
