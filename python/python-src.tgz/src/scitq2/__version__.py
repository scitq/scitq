# generated at build time
__version__ = '0.8.2.dev13+g5f12f15.dev0.b20260515205442'
__commit__ = '5f12f15'
__build_time__ = '2026-05-15T20:54:42Z'
