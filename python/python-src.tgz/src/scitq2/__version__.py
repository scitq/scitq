# generated at build time
__version__ = '0.9.2.dev6+g04b1d1c.dev0.b20260921074416'
__commit__ = '04b1d1c'
__build_time__ = '2026-09-21T07:44:16Z'
