# generated at build time
__version__ = '0.8.2.dev53+g761e69d.dev0.b20260606102520'
__commit__ = '761e69d'
__build_time__ = '2026-06-06T10:25:20Z'
