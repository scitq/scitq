# generated at build time
__version__ = '0.7.2.dev2+gf3f1e17.dev0'
__commit__ = 'f3f1e17'
__build_time__ = '2026-04-12T08:41:42Z'
