# generated at build time
__version__ = '0.7.4.dev14+g03a9115.dev0'
__commit__ = '03a9115'
__build_time__ = '2026-04-22T06:59:29Z'
