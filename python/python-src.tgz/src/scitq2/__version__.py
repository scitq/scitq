# generated at build time
__version__ = '0.7.2.dev0'
__commit__ = 'eca4edf'
__build_time__ = '2026-04-12T08:10:12Z'
