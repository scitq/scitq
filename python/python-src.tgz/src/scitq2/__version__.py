# generated at build time
__version__ = '0.7.4.dev15+g5b6b6b8.dev0'
__commit__ = '5b6b6b8'
__build_time__ = '2026-04-22T07:47:00Z'
