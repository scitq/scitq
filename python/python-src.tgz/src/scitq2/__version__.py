# generated at build time
__version__ = '0.8.7.dev8+gd89a7d4.dev0.b20260618132612'
__commit__ = 'd89a7d4'
__build_time__ = '2026-06-18T13:26:12Z'
