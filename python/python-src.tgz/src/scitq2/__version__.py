# generated at build time
__version__ = '0.8.2.dev26+ga43bf6d.dev0.b20260519210614'
__commit__ = 'a43bf6d'
__build_time__ = '2026-05-19T21:06:14Z'
