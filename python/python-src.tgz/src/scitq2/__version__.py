# generated at build time
__version__ = '0.9.1.dev3+gf472a6e.dev0.b20260820105921'
__commit__ = 'f472a6e'
__build_time__ = '2026-08-20T10:59:21Z'
