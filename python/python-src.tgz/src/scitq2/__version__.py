# generated at build time
__version__ = '0.7.7.dev2+g32e6303.dev0'
__commit__ = '32e6303'
__build_time__ = '2026-04-30T06:21:59Z'
