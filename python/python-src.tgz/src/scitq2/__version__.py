# generated at build time
__version__ = '0.7.4.dev19+gd88038a.dev0'
__commit__ = 'd88038a'
__build_time__ = '2026-04-23T06:14:22Z'
