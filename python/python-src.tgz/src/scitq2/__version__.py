# generated at build time
__version__ = '0.8.2.dev51+g68a1b85.dev0.b20260606084324'
__commit__ = '68a1b85'
__build_time__ = '2026-06-06T08:43:24Z'
