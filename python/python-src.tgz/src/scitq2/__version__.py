# generated at build time
__version__ = '0.7.8.dev3+g21c65a8.dev0'
__commit__ = '21c65a8'
__build_time__ = '2026-05-03T15:21:44Z'
