# generated at build time
__version__ = '0.9.2.dev4+g52b0025.dev0.b20260920155119'
__commit__ = '52b0025'
__build_time__ = '2026-09-20T15:51:19Z'
