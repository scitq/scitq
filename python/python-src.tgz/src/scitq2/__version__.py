# generated at build time
__version__ = '0.7.1.dev13+g079bc76.dev0'
__commit__ = '079bc76'
__build_time__ = '2026-04-08T10:43:18Z'
