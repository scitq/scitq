# generated at build time
__version__ = '0.7.1.dev16+gc3eab15.dev0'
__commit__ = 'c3eab15'
__build_time__ = '2026-04-08T12:49:43Z'
