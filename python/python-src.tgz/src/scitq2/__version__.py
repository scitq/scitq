# generated at build time
__version__ = '0.8.2.dev56+g6b72567.dev0.b20260608074419'
__commit__ = '6b72567'
__build_time__ = '2026-06-08T07:44:19Z'
