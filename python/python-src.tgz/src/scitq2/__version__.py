# generated at build time
__version__ = '0.7.2.dev1+gf16e3c1.dev0'
__commit__ = 'f16e3c1'
__build_time__ = '2026-04-12T08:29:43Z'
