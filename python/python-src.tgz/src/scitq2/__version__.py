# generated at build time
__version__ = '0.7.1.dev8+gb39584f.dev0'
__commit__ = 'b39584f'
__build_time__ = '2026-04-06T13:41:57Z'
