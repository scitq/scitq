import argparse
import json
import inspect
import os
import sys
import ast
import hashlib
from typing import Callable, Type, Optional, Dict, get_type_hints
from scitq2.param import ParamSpec
from scitq2.workflow import Workflow
from scitq2.grpc_client import Scitq2Client
import re
import traceback
import grpc

try:
    from scitq2.__version__ import __version__ as _scitq2_version
except ImportError:
    _scitq2_version = "0.0.0+dev"


def _compute_script_identity(func: Callable) -> tuple[str, str]:
    """Return (script_name, script_sha256) for the module defining `func`.
    Falls back to sys.argv[0] if the source file isn't readable. Failures
    degrade gracefully — ad-hoc registration is traceability, never a gate."""
    path = None
    try:
        path = inspect.getsourcefile(func) or inspect.getfile(func)
    except TypeError:
        path = None
    if not path or not os.path.isfile(path):
        path = sys.argv[0] if sys.argv else "<unknown>"
    name = os.path.basename(path) if path else "<unknown>"
    sha = ""
    try:
        if os.path.isfile(path):
            h = hashlib.sha256()
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(65536), b""):
                    h.update(chunk)
            sha = h.hexdigest()
    except OSError:
        sha = ""
    return name, sha

class WorkflowDefinitionError(Exception):
    pass


def find_param_class_from_func(func: Callable) -> Optional[Type]:
    sig = inspect.signature(func)
    params = list(sig.parameters.values())

    if len(params) == 0:
        return None
    if len(params) != 1:
        raise ValueError("Workflow function must take zero or one parameter")

    param = params[0]
    annotation = param.annotation

    if annotation is inspect.Parameter.empty:
        raise ValueError("Workflow parameter must have a type annotation")

    if isinstance(annotation, str):
        annotation = get_type_hints(func).get(param.name)

    if not isinstance(annotation, type):
        raise ValueError("Workflow parameter must be a class")

    if annotation.__class__ is not ParamSpec:
        raise ValueError("Workflow parameter class must use ParamSpec as metaclass")

    return annotation


def extract_workflow_metadata(source_code: str) -> Dict[str, str]:
    """
    Extracts name, description, and version from the first Workflow(...) call.
    Raises WorkflowDefinitionError if values are missing or non-literals.
    """
    tree = ast.parse(source_code)

    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "Workflow":
            result = {}
            for field in {"name", "description", "version"}:
                value = next((kw.value for kw in node.keywords if kw.arg == field), None)
                if value is None:
                    continue
                if isinstance(value, ast.Str):
                    result[field] = value.s
                else:
                    raise WorkflowDefinitionError(
                        f"The workflow metadata field '{field}' must be a plain string literal, "
                        f"not an expression or f-string (got AST node: {type(value).__name__})"
                    )

            missing = {"name", "description", "version"} - result.keys()
            if missing:
                raise WorkflowDefinitionError(
                    f"Missing required workflow metadata field(s): {', '.join(sorted(missing))}."
                )

            return result

    raise WorkflowDefinitionError("No Workflow(...) declaration found in the script.")

def check_triple_quoted_strings_for_issues(source_code: str, filename: str):
    """
    Emit warnings for triple-quoted strings used in workflow scripts
    when backslashes or curly braces may cause issues without appropriate prefixing.
    """
    triple_quoted_re = re.compile(r'''(?P<prefix>[frFR]{,2})("""|\''')(.*?)(\2)''', re.DOTALL)

    for match in triple_quoted_re.finditer(source_code):
        prefix = match.group("prefix").lower()
        raw_str = match.group(0)
        body = match.group(3)
        lineno = source_code[:match.start()].count('\n') + 1

        # Rule 1: f-string without raw prefix
        if prefix == "f":
            print(f"⚠️ Warning: line {lineno} in {filename} uses a non-raw f-string for `command=`. Use fr\"...\" instead.", file=sys.stderr)

        # Rule 2: plain quoted string (no prefix)
        elif prefix == "":
            if "\\" in body:
                print(f"⚠️ Warning: line {lineno} in {filename} uses triple-quoted string with backslashes. Use raw string (r\"\"\"...\") to avoid escape issues.", file=sys.stderr)
            elif "{" in body or "}" in body:
                print(f"⚠️ Warning: line {lineno} in {filename} uses a non-raw string with curly braces. Use fr\"...\" instead.", file=sys.stderr)

        # Rule 3: raw string with curly braces
        elif prefix == "r" and ("{" in body or "}" in body):
            print(f"⚠️ Warning: line {lineno} in {filename} uses a raw string with curly braces. Use fr\"...\" instead.", file=sys.stderr)

        # Rule 4: plain string with backslash
        elif prefix == "" and ("\\" in body):
            print(f"⚠️ Warning: line {lineno} in {filename} uses triple-quoted string with backslashes. Use raw string (r\"\"\"...\") to avoid escape issues.", file=sys.stderr)


def _handle_grpc_error(e: grpc.RpcError):
    """Handle gRPC errors with user-friendly messages."""
    details = e.details() if hasattr(e, 'details') else str(e)
    if "CERTIFICATE_VERIFY_FAILED" in details or "Ssl handshake failed" in details:
        print(
            f"❌ SSL certificate verification failed when connecting to the scitq server.\n"
            f"   Did you forget to set the SSL certificate? Run:\n\n"
            f"     export SCITQ_SSL_CERTIFICATE=$(scitq cert)\n",
            file=sys.stderr
        )
    else:
        print(f"❌ gRPC connection error: {details}", file=sys.stderr)
        traceback.print_exc(file=sys.stderr)
    sys.exit(1)


def run(func: Callable, live: bool = False):
    """
    Run a workflow function that may optionally take a Params class instance.

    Behavior:
    - --params: Outputs the parameter schema as JSON.
    - --values: Parses values and runs the workflow.
    - --metadata: Extracts workflow metadata (static AST inspection).
    - --live: Keep the DSL running for dynamic task submission (optimization loops).
    - No args:
        - If function takes no parameter, calls directly.
        - Otherwise, prints usage error.

    When live=True (or --live flag), the workflow function receives a LiveContext
    as its second argument: func(workflow, ctx) or func(params, workflow, ctx).
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--params", action="store_true", help="Print the parameter schema as JSON.")
    parser.add_argument("--values", type=str, help="JSON dictionary of parameter values.")
    parser.add_argument("--metadata", action="store_true", help="Print workflow metadata (name, version, description).")
    parser.add_argument("--standalone", action="store_true", help="Set workflow to Running after submission (local run).")
    parser.add_argument("--debug", action="store_true", help="Run in Debug mode with interactive task selection.")
    parser.add_argument("--dry-run", action="store_true", dest="dry_run", help="Create the workflow, verify it, then delete it without launching.")
    parser.add_argument("--no-recruiters", action="store_true", dest="no_recruiters", help="Create workflow without recruiters.")
    parser.add_argument("--opportunistic", action="store_true", help="Enable opportunistic reuse of previous results.")
    parser.add_argument("--untrusted", type=str, default="", help="Comma-separated step names to force re-execute.")
    parser.add_argument("--live", action="store_true", help="Keep DSL running for dynamic task submission.")
    args = parser.parse_args()

    try:
        param_class = find_param_class_from_func(func)
    except Exception as e:
        print(f"❌ Invalid workflow function signature: {e}", file=sys.stderr)
        sys.exit(1)

    if args.metadata:
        # Load the source code of the function to extract metadata
        source_file = inspect.getsourcefile(func)
        with open(source_file, "r", encoding="utf-8") as f:
            source_code = f.read()

        metadata = extract_workflow_metadata(source_code)
        if metadata is None:
            print("No metadata found in the workflow function", file=sys.stderr)
            sys.exit(1)
        if not metadata.get("name"):
            print("No name found in the workflow function metadata", file=sys.stderr)
            sys.exit(1)
        if not metadata.get("version"):
            print("No version found in the workflow function metadata", file=sys.stderr)
            sys.exit(1)
        if not metadata.get("description"):
            print("No description found in the workflow function metadata", file=sys.stderr)
            sys.exit(1)

        # Emit warnings on possibly misquoted command strings
        check_triple_quoted_strings_for_issues(source_code, filename=source_file)

        print(json.dumps(metadata, indent=2))
        return

    if args.params:
        if param_class is None:
            print("[]")
        else:
            print(json.dumps(param_class.schema(), indent=2))
        return

    result = None
    has_run = False
    if args.values and args.values!='{}':
        if param_class is None:
            print("❌ --values was provided but the workflow function does not accept parameters.", file=sys.stderr)
            sys.exit(1)
        try:
            values = json.loads(args.values)
            param_instance = param_class.parse(values)
            result = func(param_instance)
            has_run = True
        except grpc.RpcError as e:
            _handle_grpc_error(e)
        except Exception as e:
            print(f"❌ Failed to parse values or execute workflow: {e}", file=sys.stderr)
            traceback.print_exc(file=sys.stderr)
            sys.exit(1)

    if param_class is None:
        try:
            result = func()
            has_run = True
        except grpc.RpcError as e:
            _handle_grpc_error(e)
        except Exception as e:
            print(f"❌ Failed to parse values or execute workflow: {e}", file=sys.stderr)
            traceback.print_exc(file=sys.stderr)
            sys.exit(1)

    if has_run:
        if isinstance(result, Workflow):
            workflow = result
        elif result is None and Workflow.last_created is not None:
            workflow = Workflow.last_created
        else:
            print(
                f"❌ {func.__name__} did not return a Workflow object "
                f"and no Workflow instance was detected."
            ) 
            sys.exit(1)
        if args.standalone and args.debug:
            print("❌ --standalone and --debug cannot be used together.", file=sys.stderr)
            sys.exit(1)
        if args.dry_run and args.debug:
            print("❌ --dry-run and --debug cannot be used together.", file=sys.stderr)
            sys.exit(1)
        # Default to standalone when running outside the template engine
        standalone = args.standalone or not os.environ.get("SCITQ_TEMPLATE_RUN_ID")
        try:
            client = Scitq2Client()
            # Ad-hoc run registration: when the script is invoked directly
            # (not via RunTemplate on the server), record its identity on
            # the server as a template_run with NULL workflow_template_id.
            # This lets the workflow answer "what launched me?" even for
            # local-python invocations. Reuses the existing compile() path
            # by seeding SCITQ_TEMPLATE_RUN_ID in the current process env.
            if standalone and not os.environ.get("SCITQ_TEMPLATE_RUN_ID") and not args.dry_run:
                try:
                    script_name, script_sha = _compute_script_identity(func)
                    param_values_json = args.values if (args.values and args.values != '{}') else "{}"
                    module_pins_json = json.dumps({"scitq2": _scitq2_version})
                    tr_id = client.register_adhoc_run(
                        script_name=script_name,
                        script_sha256=script_sha,
                        param_values_json=param_values_json,
                        module_pins_json=module_pins_json,
                    )
                    os.environ["SCITQ_TEMPLATE_RUN_ID"] = str(tr_id)
                except grpc.RpcError as e:
                    # Non-fatal: registration is traceability only. Log and continue.
                    print(f"⚠️ Could not register ad-hoc template_run (traceability only): "
                          f"{e.details() if hasattr(e, 'details') else e}", file=sys.stderr)
            workflow_status = "D" if args.debug else None
            activate = standalone and not args.debug and not args.dry_run
            if args.no_recruiters:
                workflow.worker_pool = None
                for step in workflow.steps:
                    step.worker_pool = None
            untrusted_list = [s.strip() for s in args.untrusted.split(",") if s.strip()] if args.untrusted else []
            workflow.compile(client, activate_leading_tasks=activate, workflow_status=workflow_status,
                             opportunistic=args.opportunistic, untrusted=untrusted_list)
        except grpc.RpcError as e:
            _handle_grpc_error(e)
        if args.dry_run:
            client.delete_workflow(workflow.workflow_id)
            print(f"✅ Dry run successful: workflow '{workflow.full_name}' created and deleted.")
            return
        if args.debug:
            from scitq2 import debugger
            debugger.run_debug(client, workflow.workflow_id, maximum_workers=workflow.max_recruited)
    else:
        print("❌ Either --metadata, --params or --values must be provided.", file=sys.stderr)
        sys.exit(1)
